from DDPG_omnicopter2D import Agent
import gym
import numpy as np
from utils import plotLearning
import math
import matplotlib.pyplot as plt

def calcDerivatives(x,act,xd,m = 1,Ixx = 0.2,l = 0.2):
    Tr = act[0]
    Tl = act[1]
    phi = x[4]
    
    phidd = 0.2*(Tl-Tr)
    ydd = (Tr+Tl)*np.sin(phi)
    zdd = (Tr+Tl)*np.cos(phi)-10

    xd[0] = 0#x[1]
    xd[1] = 0#ydd
    xd[2] = 0#x[3]
    xd[3] = 0#zdd
    xd[4] = x[5]
    xd[5] = phidd
    return xd

def cal_polt(x, act, length_half = 0.5):
    
    Tl = act[0]
    Tr = act[1]
    
    y = x[0]
    z = x[2]

    phi = x[4]
    phil = 0#7x[6]
    phir = 0#x[7]

    body_l_y = y - length_half*np.cos(phi)
    body_l_z = z - length_half*np.sin(phi)

    body_r_y = y + length_half*np.cos(phi)
    body_r_z = z + length_half*np.sin(phi)

    T_l_position_y = body_l_y - 0.5*(Tl+0.5) * np.cos(np.pi/2-phi-phil)
    T_l_position_z = body_l_z + 0.5*(Tl+0.5) * np.sin(np.pi/2-phi-phil)

    T_r_position_y = body_r_y + 0.5*(Tr+0.5) * np.cos(np.pi/2+phi-phir)
    T_r_position_z = body_r_z + 0.5*(Tr+0.5) * np.sin(np.pi/2+phi-phir)

    x_points = [[body_l_y, body_r_y],
         [body_l_y, T_l_position_y],
         [body_r_y, T_r_position_y]]
    y_points = [[body_l_z, body_r_z],
         [body_l_z, T_l_position_z],
         [body_r_z, T_r_position_z]]

    return x_points, y_points
obs = np.array([0,0,0,0,0,0],dtype = 'f')
xd = np.array([0,0,0,0,0,0],dtype = 'f')
dt = 0.01
while True:
    act = [0,5]
    xd = calcDerivatives(obs,act,xd)
    #print(xd)
    new_state = obs + xd*dt
    print(new_state)
    x_points,y_points = cal_polt(new_state, act, length_half = 0.5)
    plt.xlim(-10,10)
    plt.ylim(-10,10)
    #plt.title(act)
    for t in range(3):
        plt.plot(x_points[t], y_points[t])
    plt.draw()
    plt.pause(0.005)
    plt.cla()
    obs = new_state




















     
