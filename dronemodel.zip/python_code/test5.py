


def idx_demo(a=5,b=3,c):
    return a * b*c


c = 7
#print(idx_demo(c=c))
