# The basics
#matplotlib inline
import matplotlib.pyplot as plt
import time
import itertools
import matplotlib
from mpl_toolkits.mplot3d import Axes3D
from collections import deque

import numpy as np
import sys
import os
import random

from collections import namedtuple
import collections
import copy

# Import the open AI gym
import gym

# Keras and backend for neural networks
import keras
from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import Adam
from keras import backend as K
import tensorflow as tf

# Misc
import warnings
warnings.filterwarnings('ignore')


# use full window width
from IPython.core.display import display, HTML
#display(HTML("<style>.container { width:100% !important; }</style>"))



print(sys.version)
print(os.path)
print("Keras: ",keras.__version__)
print("TF: ",tf.__version__)
print("\n\nYou are good to go")





class NNFunctionApproximatorJointKeras():
    """ A basic MLP neural network approximator and estimator using Keras     
    """
    
    def __init__(self, alpha, d_states, n_actions, nn_config, verbose=False):        
        self.alpha = alpha              # learning rate
        self.nn_config = nn_config      # determines the size of the hidden layer (if any)             
        self.n_actions = n_actions        
        self.d_states = d_states
        self.verbose=verbose # Print debug information        
        self.n_layers = len(nn_config)                
        self.model = self._build_model()

        self.alpha_factor = 1.0001
                        
    def _huber_loss(self,y_true, y_pred, clip_delta=0.01):
        """
        Huber loss (for use in Keras), see https://en.wikipedia.org/wiki/Huber_loss
        The huber loss tends to provide more robust learning in RL settings where there are 
        often "outliers" before the functions has converged.
        """
        error = y_true - y_pred
        cond  = K.abs(error) <= clip_delta
        squared_loss = 0.5 * K.square(error)
        quadratic_loss = 0.5 * K.square(clip_delta) + clip_delta * (K.abs(error) - clip_delta)
        return K.mean(tf.where(cond, squared_loss, quadratic_loss))
        

    def _build_model(self):
        # Neural Net for Deep-Q learning 
        model = Sequential()
        for ilayer in self.nn_config:
            model.add(Dense(ilayer, input_dim=self.d_states, activation='relu'))        
        model.add(Dense(self.n_actions, activation='linear'))
        model.compile(loss=self._huber_loss, # define a special loss function
                      optimizer=Adam(lr=self.alpha, clipnorm=10.)) # specify the optimiser, we clip the gradient of the norm which can make traning more robust
        return model

    def predict(self, s, a=None):              
        if a==None:            
            return self._predict_nn(s)
        else:                        
            return self._predict_nn(s)[a]
        
    def _predict_nn(self,state_hat):                          
        """
        Predict the output of the neural netwwork (note: these can be vectors)
        """                
        x = self.model.predict(state_hat)                                                    
        return x
  
    def update(self, states, td_target):           
        self.model.fit(states, td_target, epochs=1, verbose=0) # take one gradient step usign Adam
        #self.alpha  = self.alpha_factor * self.alpha
        return

Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward','is_not_terminal_state'))

class ReplayMemory():
    """
    Implement a replay buffer using the deque collection
    """

    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = deque(maxlen=capacity)
        

    def push(self, *args):
        """Saves a transition."""
        self.memory.append(Transition(*args))

    def pop(self):
        return self.memoery.pop()

    def sample(self, batch_size):
        
        return random.sample(self.memory, batch_size)
        

    def __len__(self):
        return len(self.memory)



import pandas as pd
def plot_episode_stats(stats, smoothing_window):
    # Plot the episode length over time
    #fig1 = plt.figure(figsize=(10,5))
    plt.plot(stats.episode_lengths)
    plt.xlabel("Episode")
    plt.ylabel("Episode Length")
    plt.title("Episode Length over Time")
    plt.grid(True)
    plt.show()
    
    # Plot the episode reward over time
    
    #fig2 = plt.figure(figsize=(10,5))
    rewards_smoothed = pd.Series(stats.episode_rewards).rolling(smoothing_window, min_periods=smoothing_window).mean()
    plt.plot(rewards_smoothed)
    plt.xlabel("Episode")
    plt.ylabel("Episode Reward (Smoothed)")
    plt.title("Episode Reward over Time (Smoothed over window size {})".format(smoothing_window))
    plt.grid(True)
    plt.show()


import virl

alpha= 0.001          # learning rate/stepsize, 0.001 seems to be a good choice
nn_config   = [48,48] # size of the hidden layers
BATCH_SIZE  = 32     # numbe rof samples in a batch
BUFFER_SIZE = 20000   # size of the replay buffer


reward = np.array([0.0, 0.0, 0.0, 0.0])
      
memory = ReplayMemory(BUFFER_SIZE) # init the replay memory    
env = virl.Epidemic(stochastic=False, noisy=False)
n_actions = env.action_space.n      
print('n_actions',n_actions)
d_states  = env.observation_space.shape[0]
print('d_states',d_states)
"""y0 = -2.0
z0 = -6.0
phi0 = 0.0
n_actions = 4     
print('n_actions',n_actions)
d_states  = np.array([[5.0],[0.1],[5.0],[0.5],
                      [reward[0]],[reward[1]],[reward[2]],[reward[3]],
                       [y0],[0.0],[z0],[0.0],[phi0],[0.0],[0.0],[0.0]])

print('d_states',d_states) """


# Init the two networks
nn_func_approximator = NNFunctionApproximatorJointKeras(alpha, d_states, n_actions, nn_config)
nn_func_approximator_target = NNFunctionApproximatorJointKeras(alpha, d_states, n_actions, nn_config)

"""stats = q_learning_nn(nn_func_approximator, nn_func_approximator_target, 10, max_steps_per_episode=200, discount_factor=0.99,
                        epsilon_init=0.1, epsilon_decay=0.995, epsilon_min=0.001, use_batch_updates=True,show=True,
                        fn_model_in=None, fn_model_out="test.h5",imageid=i)"""

state = np.array([[0],[0],[0],[0]])
act_values = nn_func_approximator.predict(state)[0]

print(act_values)
print(1234567)






