import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation 

def cal_polt(x, act, length_half = 0.5):
    
    Tl = act[0]
    Tr = act[3]
    
    y = x[0]
    z = x[3]

    phi = x[4]
    phil = x[6]
    phir = x[7]

    body_l_y = y - length_half*np.cos(phi)
    body_l_z = z - length_half*np.sin(phi)

    body_r_y = y + length_half*np.cos(phi)
    body_r_z = z + length_half*np.sin(phi)

    T_l_position_y = body_l_y - 0.05*Tl * np.cos(np.pi-phi-phil)
    T_l_position_z = body_l_z + 0.05*Tl * np.sin(np.pi-phi-phil)

    T_r_position_y = body_r_y + 0.05*Tr * np.cos(np.pi+phi-phir)
    T_r_position_z = body_r_z + 0.05*Tr * np.sin(np.pi+phi-phir)

    x_points = [[body_l_y, body_r_y],
         [body_l_y, T_l_position_y],
         [body_r_y, T_r_position_y]]
    y_points = [[body_l_z, body_r_z],
         [body_l_z, T_l_position_z],
         [body_r_z, T_r_position_z]]

    return x_points, y_points
    
for j in range(100):
    phi = j*0.03
    phil = j*0.04
    phir = j*0.045

    length_half = 0.5
    Tl = 5
    Tr = 4

    y = 1
    z = 2

    body_l_y = y - length_half*np.cos(phi)
    body_l_z = z - length_half*np.sin(phi)

    body_r_y = y + length_half*np.cos(phi)
    body_r_z = z + length_half*np.sin(phi)

    T_l_position_y = body_l_y - 0.05*Tl * np.cos(np.pi-phi-phil)
    T_l_position_z = body_l_z + 0.05*Tl * np.sin(np.pi-phi-phil)

    T_r_position_y = body_r_y + 0.05*Tr * np.cos(np.pi+phi-phir)
    T_r_position_z = body_r_z + 0.05*Tr * np.sin(np.pi+phi-phir)

    x = [[body_l_y, body_r_y],
         [body_l_y, T_l_position_y],
         [body_r_y, T_r_position_y]]
    y = [[body_l_z, body_r_z],
         [body_l_z, T_l_position_z],
         [body_r_z, T_r_position_z]]
    print(j)
    
    plt.xlim(-5,5)
    plt.ylim(-5,5)
    for i in range(3):
        plt.plot(x[i], y[i])
    plt.draw()
    plt.pause(0.05)
    plt.cla()
    #plt.close(fig)
        

