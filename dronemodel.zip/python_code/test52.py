import msvcrt
while True:
    pressedKey = msvcrt.getch()
    print(pressedKey)
    print(123123)
    if pressedKey == b'x':
        print(123123123423)
        break
