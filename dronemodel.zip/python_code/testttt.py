
ranges = [0,0,0,1,4,2,2,2,2,4,0,0,0,5,4,0,0,5,3,0,1,1,5,1,1,2,4,1,0,4,3,5,1,0,3,3,4,2,2,4,3,1,1,0,4,0,2,1,4,0,0,3,3,1,1,4,4,2,0,3,4,0,1,5,3,0,1,0,2]
n = 68
area = [10*n,-10*n]

area_data = []
for i in range(n+1):
    
    if ranges[i] == 0:
        continue
    left = i - ranges[i]
    right = i + ranges[i]
    
    if left <= 0 and right >= area[1]:
        #print(5)
        area[0] = left
        area[1] = right
        area_data= [[left,right]]
    if left < area[0] or right > area[1]:
        
        """if len(data_save) > 1:
            if left < area[0]:
                area[0] = left
                area_data.append([left,right])
            if right > area[1]:
                area[1] = right
                area_data.append([left,right])
        else:"""
        if left < area[0]:# and area[0] > 0:
            area[0] = left
            area_data.append([left,right])
        if right > area[1]:# and area[1] < n:
            area[1] = right
            area_data.append([left,right])
        data_save = []
        left_min = area_data[0][0]
        right_max = area_data[0][1]
        for j in range(len(area_data)-1):
            left_tem = area_data[j][0]
            right_tem = area_data[j][1]
            
            for z in range(j+1,len(area_data)):
                left_tem2 = area_data[z][0]
                right_tem2 = area_data[z][1]
                print(j,left_tem2,right_max,area_data[z])
                if left_tem > left_min and left_tem2 <= right_max and right_tem < right_tem2:
                    data_save.append(area_data[j])
                    #print(j,area_data[j])
                #print('11231231231',left_tem2,right_max,right_tem2)
                elif left_tem2 < right_max and right_tem2 > n and area[1] >= n and right_max >= n:
                    #print(j,left_tem2,right_max,area_data[z])
                    data_save.append(area_data[z])
            if left_min > left_tem:
                left_min = left_tem
            if right_max < right_tem:
                right_max = right_tem
        #print('data_save',data_save)
        
        #print('asd',area_data)
        #print('asd',data_save)
        for j in range(len(data_save)):
            area_data.remove(data_save[j])
    print('area',area)
    print([left,right])
    
    print(area_data)
#print(area_data)
#print(area)
if area[0] <= 0 and area[1] >= n:
    print(len(area_data))
#else:
    #return -1
