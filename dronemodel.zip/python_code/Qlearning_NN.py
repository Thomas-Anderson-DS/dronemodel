# The basics
#matplotlib inline
import matplotlib.pyplot as plt
import time
import itertools
import matplotlib
from mpl_toolkits.mplot3d import Axes3D
from collections import deque

import numpy as np
import sys
import os
import random

from collections import namedtuple
import collections
import copy

# Import the open AI gym
import gym

# Keras and backend for neural networks
import keras
from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import Adam
from keras import backend as K
import tensorflow as tf

# Misc
import warnings
warnings.filterwarnings('ignore')


# use full window width
from IPython.core.display import display, HTML
#display(HTML("<style>.container { width:100% !important; }</style>"))



print(sys.version)
print(os.path)
print("Keras: ",keras.__version__)
print("TF: ",tf.__version__)
print("\n\nYou are good to go")





class NNFunctionApproximatorJointKeras():
    """ A basic MLP neural network approximator and estimator using Keras     
    """
    
    def __init__(self, alpha, d_states, n_actions, nn_config, verbose=False):        
        self.alpha = alpha              # learning rate
        self.nn_config = nn_config      # determines the size of the hidden layer (if any)             
        self.n_actions = n_actions        
        self.d_states = d_states
        self.verbose=verbose # Print debug information        
        self.n_layers = len(nn_config)                
        self.model = self._build_model()

        self.alpha_factor = 1.0001
                        
    def _huber_loss(self,y_true, y_pred, clip_delta=0.01):
        """
        Huber loss (for use in Keras), see https://en.wikipedia.org/wiki/Huber_loss
        The huber loss tends to provide more robust learning in RL settings where there are 
        often "outliers" before the functions has converged.
        """
        error = y_true - y_pred
        cond  = K.abs(error) <= clip_delta
        squared_loss = 0.5 * K.square(error)
        quadratic_loss = 0.5 * K.square(clip_delta) + clip_delta * (K.abs(error) - clip_delta)
        return K.mean(tf.where(cond, squared_loss, quadratic_loss))
        

    def _build_model(self):
        # Neural Net for Deep-Q learning 
        model = Sequential()
        for ilayer in self.nn_config:
            model.add(Dense(ilayer, input_dim=self.d_states, activation='relu'))        
        model.add(Dense(self.n_actions, activation='linear'))
        model.compile(loss=self._huber_loss, # define a special loss function
                      optimizer=Adam(lr=self.alpha, clipnorm=10.)) # specify the optimiser, we clip the gradient of the norm which can make traning more robust
        return model

    def predict(self, s, a=None):              
        if a==None:            
            return self._predict_nn(s)
        else:                        
            return self._predict_nn(s)[a]
        
    def _predict_nn(self,state_hat):                          
        """
        Predict the output of the neural netwwork (note: these can be vectors)
        """                
        x = self.model.predict(state_hat)                                                    
        return x
  
    def update(self, states, td_target):           
        self.model.fit(states, td_target, epochs=1, verbose=0) # take one gradient step usign Adam
        #self.alpha  = self.alpha_factor * self.alpha
        return


# Keep track of some stats
EpisodeStats = namedtuple("Stats",["episode_lengths", "episode_rewards"])

# Main Q-learner
def q_learning_nn(func_approximator, func_approximator_target, num_episodes,max_steps_per_episode=500,
                  discount_factor=0.95, epsilon_init=0.01, epsilon_decay=0.99995,epsilon_min=0.01,
                  use_batch_updates=True, show=False, fn_model_in=None, fn_model_out=None,produce_image=1,imageid=0):
    """
    Q-Learning algorithm for Q-learning using Function Approximations.
    Finds the optimal greedy policy while following an explorative greedy policy.
    
    Args:
        env: OpenAI environment.(omnicopter2D model)
        func_approximator: Action-Value function estimator, behavior policy (i.e. the function which determines the next action)
        func_approximator_target: Action-Value function estimator, updated less frequenty than the behavior policy 
        num_episodes: Number of episodes to run for.
        max_steps_per_episode: Max number of steps per episodes
        discount_factor: Gamma discount factor.
        epsilon_init: Exploration strategy; chance the sample a random action. Float between 0 and 1.
        epsilon_decay: Each episode, epsilon is decayed by this factor
        epislon_min: Min epsilon value        
        use_batch_updates=True, 
        show: Render the environment (mainly for test/demo) 
        fn_model_in: Load the model from the file if not None
        fn_model_out: File name of the saved model, saves the best model in the last 100 episodes

    Returns:
        An EpisodeStats object with two numpy arrays for episode_lengths and episode_rewards.
    """

    total_reward = []
    average_reward = []
    best_reward_episode = -10
    second_reward = 0
    best_episode = []
    best_action_save = []
    best_reward_save = []

    all_loss_save = []


    infect_rate = []
      
    memory = ReplayMemory(BUFFER_SIZE) # init the replay memory    
    
    n_actions = np.array([[5.0],[0.1],[5.0],[0.5]])      
    print('n_actions',n_actions)
    d_states  = np.array([[y0],[0.0],[z0],[0.0],[phi0],[0.0],[0.0],[0.0]])
    print('d_states',d_states)
    best_reward = 0

    # Synch the target and behavior network
    if not fn_model_in is None:
        func_approximator.model.load_weights(fn_model_in)
    func_approximator_target.model.set_weights(func_approximator.model.get_weights())

    # Keeps track of useful statistics
    stats = EpisodeStats(
        episode_lengths=np.zeros(num_episodes),
        episode_rewards=np.zeros(num_episodes))            

    epsilon = epsilon_init

    for i_episode in range(num_episodes):
        sys.stdout.flush()
               
        # Reset the environment and pick the first action
        
        # One step in the environment
        states_save = []
        rewards_save = []
        action_save = []

        loss_save = []
        
        
        for t in range(max_steps_per_episode):#itertools.count():
            
            #if(show):
                #env.render()

            # Select an action usign and epsilon greedy policy based on the main behavior network
            if np.random.rand() <= epsilon:
                action = random.randrange(n_actions)
            else:
                act_values = func_approximator.predict(state)[0]
                
                action = np.argmax(act_values)  # returns action                        

            
            action_save.append(action)
            # Take a step            
            next_state, reward, done, _ = env.step(action)
            
            states_save.append(next_state)
            
            
            next_state = np.reshape(next_state, [1, d_states] )
            
            
            
            rewards_save.append(reward)
            
            # Add observation to the replay buffer
            if done:
                memory.push(state, action, next_state, reward, 0.0)
                
                
                
            else:
                memory.push(state, action, next_state, reward, 1.0)
           
            # Update statistics
            stats.episode_rewards[i_episode] += reward
            stats.episode_lengths[i_episode] = t
                     
            # Update network (if learning is on, i.e. alpha>0 and we have enough samples in memory)
            if func_approximator.alpha > 0.0 and len(memory) >= BATCH_SIZE: 
                
                # Fetch a bacth from the replay buffer and extract as numpy arrays 
                transitions = memory.sample(BATCH_SIZE)
                
                batch = Transition(*zip(*transitions))   
                
                
                train_rewards = np.array(batch.reward)
                
                
                train_states = np.array(batch.state)/600000000
                
                
                train_next_state = np.array(batch.next_state)/600000000
                
                
                train_actions = np.array(batch.action)
                
                
                train_is_not_terminal_state = np.array(batch.is_not_terminal_state) 
                
                                
                if(use_batch_updates):
                    # Do a single gradient step computed based on the full batch
                    train_td_targets = func_approximator.predict(train_states.reshape(BATCH_SIZE,4)) # predict current values for the given states
                    
                    q_values_next = func_approximator_target.predict(train_next_state.reshape(BATCH_SIZE,d_states))
                    
                    train_td_targetstmp = train_rewards + discount_factor * np.amax(q_values_next,axis=1)#* train_is_not_terminal_state * np.amax(q_values_next,axis=1)
                    print(np.shape(train_rewards))
                    train_td_targets[ (np.arange(BATCH_SIZE), train_actions.reshape(BATCH_SIZE,).astype(int))] = train_td_targetstmp
                    
                    func_approximator.update(train_states.reshape(BATCH_SIZE,d_states), train_td_targets) # Update the function approximator using our target

                    
                else:
                    # Do update in a truely online sense where a gradient step is performaed per observation
                    """for s in range(train_rewards.shape[0]):                        
                        target = func_approximator.predict(train_states[s])[0]
                        q_next = func_approximator_target.predict(train_next_state[s])[0]
                        target[train_actions[s]] = train_rewards[s] + discount_factor * train_is_not_terminal_state[s] * np.amax(q_next)                        
                        func_approximator.update(train_states[s], target.reshape(1,n_actions)) # Update the function approximator using our target  """                                          
                if epsilon > epsilon_min:
                    epsilon *= epsilon_decay
            
            state = next_state                
            
            # 
            if done:
                # Synch the target and behavior network
                func_approximator_target.model.set_weights(func_approximator.model.get_weights())
                
                #print the count of the loop and lets us see how the total reward for each loop changes when the program going on
                print('i_episode:',i_episode+1,'num_episodes:',num_episodes,'t/score:', t,'epsilon:',epsilon, 'func_approximator.alpha',func_approximator.alpha,'end',"\n")
                print('total reward', np.sum(rewards_save))
                   
                if fn_model_out is not None and (t >= best_reward):
                    func_approximator.model.save_weights(fn_model_out)
                    best_reward = t
                
                break
        
        if np.sum(rewards_save) > best_reward_episode:
            best_reward_episode = np.sum(rewards_save)
            best_episode = states_save
            best_action_save = action_save
            best_reward_save = rewards_save
        #save total reward
        total_reward.append(np.sum(rewards_save))
        average_reward.append(np.sum(total_reward)/i_episode)
        
    #print all the matrix, and to know what is going on inside the loop   
    """print(np.shape(train_td_targets))
    print('train_rewards',train_rewards)
    print('train_td_targets',train_td_targets)
    print('q_values_next',q_values_next)
    print('np.amax(q_values_next,axis=1)',np.amax(q_values_next,axis=1))
    print('train_td_targetstmp',train_td_targetstmp)
    print(type(train_td_targets),type(train_actions))
    print('train_states.reshape(BATCH_SIZE,d_states)',train_states.reshape(BATCH_SIZE,d_states))"""


    plt.plot(average_reward)
    plt.xlabel('episode')
    plt.ylabel('average total reward for each episode')
    plt.savefig(' averageRewards_withoutnoise'+str(imageid)+'.svg')
    plt.cla()
    
    plt.plot(total_reward)
    plt.plot(infect_rate)
    plt.legend(labels = ['total_reward', 'infect_rate-1.5'])
    plt.axhline(y=-1.0,color='r', linestyle='-')
    plt.xlabel('episode')
    plt.ylabel('total reward for each episode')
    plt.savefig(' toralRewards_withoutnoise'+str(imageid)+'.svg')
    plt.cla()
    
    """print('best reward', best_reward_episode)
    fig, axes = plt.subplots(1, 3, figsize=(20, 8))
    labels = ['s[0]: susceptibles', 's[1]: infectious', 's[2]: quarantined', 's[3]: recovereds']
    states_save_best = np.array(best_episode)
    for i in range(4):
        axes[0].plot(states_save_best[:,i], label=labels[i]);
    axes[0].set_xlabel('weeks since start of epidemic')
    axes[0].set_ylabel('State s(t)')
    axes[0].legend()
    axes[1].plot(best_reward_save);
    axes[1].set_title('Reward')
    axes[1].set_xlabel('weeks since start of epidemic')
    axes[1].set_ylabel('reward r(t)')
    plt.plot(best_action_save)
    plt.savefig(name + ' Rewards.png')


    
    fig, axes = plt.subplots(1, 3, figsize=(20, 8))
    labels = ['s[0]: susceptibles', 's[1]: infectious', 's[2]: quarantined', 's[3]: recovereds']
    states_save = np.array(states_save)
    for i in range(4):
        axes[0].plot(states_save[:,i], label=labels[i]);
    axes[0].set_xlabel('weeks since start of epidemic')
    axes[0].set_ylabel('State s(t)')
    axes[0].legend()
    axes[1].plot(rewards_save);
    axes[1].set_title('Reward')
    axes[1].set_xlabel('weeks since start of epidemic')
    axes[1].set_ylabel('reward r(t)')
    plt.plot(action_save)
    plt.show()"""
               
    return stats




Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward','is_not_terminal_state'))

class ReplayMemory():
    """
    Implement a replay buffer using the deque collection
    """

    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = deque(maxlen=capacity)
        

    def push(self, *args):
        """Saves a transition."""
        self.memory.append(Transition(*args))

    def pop(self):
        return self.memoery.pop()

    def sample(self, batch_size):
        
        return random.sample(self.memory, batch_size)
        

    def __len__(self):
        return len(self.memory)



import pandas as pd
def plot_episode_stats(stats, smoothing_window):
    # Plot the episode length over time
    #fig1 = plt.figure(figsize=(10,5))
    plt.plot(stats.episode_lengths)
    plt.xlabel("Episode")
    plt.ylabel("Episode Length")
    plt.title("Episode Length over Time")
    plt.grid(True)
    plt.show()
    
    # Plot the episode reward over time
    
    #fig2 = plt.figure(figsize=(10,5))
    rewards_smoothed = pd.Series(stats.episode_rewards).rolling(smoothing_window, min_periods=smoothing_window).mean()
    plt.plot(rewards_smoothed)
    plt.xlabel("Episode")
    plt.ylabel("Episode Reward (Smoothed)")
    plt.title("Episode Reward over Time (Smoothed over window size {})".format(smoothing_window))
    plt.grid(True)
    plt.show()




#Tarining


alpha= 0.001          # learning rate/stepsize, 0.001 seems to be a good choice
nn_config   = [96] # size of the hidden layers
BATCH_SIZE  = 32     # numbe rof samples in a batch
BUFFER_SIZE = 20000   # size of the replay buffer



# Init the two networks
nn_func_approximator = NNFunctionApproximatorJointKeras(alpha, d_states, n_actions, nn_config)
nn_func_approximator_target = NNFunctionApproximatorJointKeras(alpha, d_states, n_actions, nn_config)

stats = q_learning_nn(nn_func_approximator, nn_func_approximator_target, 10, max_steps_per_episode=200, discount_factor=0.99,
                        epsilon_init=0.1, epsilon_decay=0.995, epsilon_min=0.001, use_batch_updates=True,show=True,
                        fn_model_in=None, fn_model_out="test.h5",imageid=i)



