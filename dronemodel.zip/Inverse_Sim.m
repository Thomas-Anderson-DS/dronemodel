%% Parameters
m = 1;              % mass(kg)
Ixx = 0.1;          % roll inertia (kgm^2)
l = 0.2;            % moment arm
%eta = 0;            % magnitude of termination error
ymax=5; ymin=-5;    % max and min y-values for environment
zmax=0; zmin=-10;   % max and min z-values for environment
yp = 0; zp = -1;    % location of the landing pad (m)
phip = 0;           % orientation of landing pad (rad)
g = 9.8;             % acceleration due to gravity

t = 0;       
n = 0;       
nmax = 20;   %Maximum number of calculations for a single sample
epsilon = 0.0001;  %Upper limit of error
tmax = 150;        %Max time limitation
dt = 0.02;

load y_des.txt;
load z_des.txt;
load phi_des.txt;

y = 0;
yd = 0;
z = -5;
zd = 0;
phir = 0;
phil = 0;
phi = 0;
phid = 0;

act = [5 0.01 5 0.01];



J_matrix = [0 0 0 0;...
            0 0 0 0;...
            0 0 0 0];

correct_y = [];
correct_z = [];
correct_phi = [];
correct_act = [];
action_save = [];

error_save = [];
while t < tmax
    
    
    
    n = 0;
    disp('t');
    disp(t);
    while 1>0
        
        [ydd,zdd,phidd,phil,phir,phild,phird] = calculationstate(act,dt,phil,phir,phi,m,g,l,Ixx);
        disp('n');
        disp(n);
        disp(act);
        disp([ydd,zdd,phidd,phil,phir,phild,phird]);
        
        %yd_next = yd + ydd*dt;
        %zd_next = zd + zdd*dt;
        %phid_next = phid + phidd*dt;
        
        y_next = y + yd*dt + 0.5*ydd*dt^2;
        z_next = z + zd*dt + 0.5*zdd*dt^2;
        phi_next = phi + phid*dt + 0.5*phidd*dt^2;
        
        yd_next = yd + ydd*dt;
        zd_next = zd + zdd*dt;
        phid_next = phid + phidd*dt;
        
        phil_next = phil;% + phild*dt;
        phir_next = phir;% + phird*dt;
        
        error_y = y_next - y_des(t+1); 
        error_z = z_next - z_des(t+1);
        error_phi = phi_next - phi_des(t+1);
        flag_y = 0;
        flag_z = 0;
        flag_phi = 0;
        disp('errors in the beginning');
        disp([y_des(t+1) z_des(t+1) phi_des(t+1)]);
        disp([y_next z_next phi_next]);
        disp([error_y error_z error_phi]);
        %disp([error_y error_z error_phi] - error_save);
        
        disp([abs(error_y)<= epsilon abs(error_z)<= epsilon abs(error_phi) <= epsilon]);
        flag_y = abs(error_y)<= epsilon;
        flag_z = abs(error_z)<= epsilon;
        flag_phi = abs(error_phi)<= epsilon;
        if (flag_y && flag_z && flag_phi)
            y = y_next;
            z = z_next;
            phi = phi_next;
            yd = yd_next;
            zd = zd_next;
            phid = phid_next;
            phir = phir_next;
            phil = phir_next;
            
            correct_y = [correct_y y];
            correct_z = [correct_z z];
            correct_phi = [correct_phi phi];
            correct_act = [correct_act;...
                           act];
            action_save = [action_save;...
                            act];
            error_save = [error_save;...
                         [error_y error_z error_phi]];     
            break;
        end
        if n > nmax
            y = y_next;
            z = z_next;
            phi = phi_next;
            yd = yd_next;
            zd = zd_next;
            phid = phid_next;
            phir = phir_next;
            phil = phir_next;
            action_save = [action_save;...
                            act];
            error_save = [error_save;...
                         [error_y error_z error_phi]];
            break;
        else
            %processing J, delta_u = 0.1*u
            %change a(1)
            act_tem = act .* [1.1 1 1 1];
            [ydd_tem,zdd_tem,phidd_tem,~,~,~,~] = calculationstate(act_tem,dt,phil,phir,phi,m,g,l,Ixx);
            
            %yd_next_tem = yd + ydd_tem*dt;
            %zd_next_tem = zd + zdd_tem*dt;
            %phid_next_tem = phid + phidd_tem*dt;
            
            %y_tem = y + yd_next_tem*dt + 0.5*ydd_tem*dt^2;
            y_tem = y + yd_next*dt + 0.5*ydd_tem*dt^2;
            J_matrix(1,1) = (y_tem - y_next)/(0.1*act(1));
            
            %z_tem = z + zd_next_tem*dt + 0.5*zdd_tem*dt^2;
            z_tem = z + zd_next*dt + 0.5*zdd_tem*dt^2;
            J_matrix(2,1) = (z_tem - z_next)/(0.1*act(1));
            
            %phi_tem = phi + phid_next_tem*dt + 0.5*phidd_tem*dt^2;
            phi_tem = phi + phid_next*dt + 0.5*phidd_tem*dt^2;
            J_matrix(3,1) = (phi_tem - phi_next)/(0.1*act(1));
            
            %change a(2)
            act_tem = act .* [1 1.1 1 1];
            [ydd_tem,zdd_tem,phidd_tem,~,~,~,~] = calculationstate(act_tem,dt,phil,phir,phi,m,g,l,Ixx);
            
            %yd_next_tem = yd + ydd_tem*dt;
            %zd_next_tem = zd + zdd_tem*dt;
            %phid_next_tem = phid + phidd_tem*dt;
            
            %y_tem = y + yd_next_tem*dt + 0.5*ydd_tem*dt^2;
            y_tem = y + y_next*dt + 0.5*ydd_tem*dt^2;
            J_matrix(1,2) = (y_tem - y_next)/(0.1*act(2));
            
            %z_tem = z + zd_next_tem*dt + 0.5*zdd_tem*dt^2;
            z_tem = z + zd_next*dt + 0.5*zdd_tem*dt^2;
            J_matrix(2,2) = (z_tem - z_next)/(0.1*act(2));
            
            %phi_tem = phi + phid_next_tem*dt + 0.5*phidd_tem*dt^2;
            phi_tem = phi + phid_next*dt + 0.5*phidd_tem*dt^2;
            J_matrix(3,2) = (phi_tem - phi_next)/(0.1*act(2));
            
            %change a(3)
            act_tem = act .* [1 1 1.1 1];
            [ydd_tem,zdd_tem,phidd_tem,~,~,~,~] = calculationstate(act_tem,dt,phil,phir,phi,m,g,l,Ixx);
            
            %yd_next_tem = yd + ydd_tem*dt;
            %zd_next_tem = zd + zdd_tem*dt;
            %phid_next_tem = phid + phidd_tem*dt;
            
            %y_tem = y + yd_next_tem*dt + 0.5*ydd_tem*dt^2;
            y_tem = y + yd_next*dt + 0.5*ydd_tem*dt^2;
            J_matrix(1,3) = (y_tem - y_next)/(0.1*act(3));
            
            %z_tem = z + zd_next_tem*dt + 0.5*zdd_tem*dt^2;
            z_tem = z + zd_next*dt + 0.5*zdd_tem*dt^2;
            J_matrix(2,3) = (z_tem - z_next)/(0.1*act(3));
            
            %phi_tem = phi + phid_next_tem*dt + 0.5*phidd_tem*dt^2;
            phi_tem = phi + phid_next*dt + 0.5*phidd_tem*dt^2;
            J_matrix(3,3) = (phi_tem - phi_next)/(0.1*act(3));
            
            %change a(4)
            %disp('act_tem(4)');
            %disp(act(4));
            act_tem = act .* [1 1 1 1.1];
            [ydd_tem,zdd_tem,phidd_tem,phil_tem,phir_tem,phild_tem,phird_tem] = calculationstate(act_tem,dt,phil,phir,phi,m,g,l,Ixx);
            %disp(act_tem(4));
            %disp(phird_tem);
            
            %yd_next_tem = yd + ydd_tem*dt;
            %zd_next_tem = zd + zdd_tem*dt;
            %phid_next_tem = phid + phidd_tem*dt;
            
            %y_tem = y + yd_next_tem*dt + 0.5*ydd_tem*dt^2;
            y_tem = y + yd_next*dt + 0.5*ydd_tem*dt^2;
            J_matrix(1,4) = (y_tem - y_next)/(0.1*act(4));
            
            %z_tem = z + zd_next_tem*dt + 0.5*zdd_tem*dt^2;
            z_tem = z + zd_next*dt + 0.5*zdd_tem*dt^2;
            J_matrix(2,4) = (z_tem - z_next)/(0.1*act(4));
            
            %phi_tem = phi + phid_next_tem*dt + 0.5*phidd_tem*dt^2;
            phi_tem = phi + phid_next*dt + 0.5*phidd_tem*dt^2;
            J_matrix(3,4) = (phi_tem - phi_next)/(0.1*act(4));
            
            %disp(act);
            %disp('J_matrix');
            %disp(J_matrix);
            %disp([y_next z_next phi_next]);
            %disp([y_des(t+1) z_des(t+1) phi_des(t+1)]);
            %disp('errors');
            %disp([error_y;error_z;error_phi]);
            [U,S,V] = svd(J_matrix);
            %disp('U,S,V');
            %disp(V');
            %disp(pinv(S));
            %disp(U');
            %disp('pin J_matrix');
            
            %disp(V'*pinv(S)*U');
            
            disp('act');
            disp(act);
            disp((V'*pinv(S)*U'*[error_y;error_z;error_phi])');
            act = act - (V'*pinv(S)*U'*[error_y;error_z;error_phi])'*0.75;
            
            %disp(n);
            %disp('act after cal');
            %disp('act');
            %disp(act);
            %disp(pinv(J_matrix))
            %disp([error_y;error_z;error_phi])
            %disp(J_matrix)
            %pause(3);
        end
        n = n + 1;
    end
    
    
    t = t + 1;
end

 
function [ydd,zdd,phidd,phil,phir,phild,phird] = calculationstate(act,dt,phil,phir,phi,m,g,l,Ixx)
    Tl = act(1);
    Tr = act(3);
    phild = act(2);
    phird = act(4);
    phil = phil + phild*dt;
    phir = phir + phird*dt;

    Cpl_b = [1 0 0;...
             0 cos(phil) -sin(phil);...
             0 sin(phil) cos(phil)];

    Cpr_b = [1 0 0;...
             0 cos(phir) -sin(phir);...
             0 sin(phir) cos(phir)];

    Cb_e = [1 0 0;...
            0 cos(phi) -sin(phi);...
            0 sin(phi) cos(phi)];    

    Tvr = [0.0 0.0 -Tr];
    Tvl = [0.0 0.0 -Tl];         

    Fr_b = Cpr_b * Tvr';
    Fl_b = Cpl_b * Tvl';
    %disp('Fr_b');
    %disp(Fr_b);
    %disp('Fl_b');
    %disp(Fl_b);
    
    Fr_e = Cb_e * Fr_b;
    Fl_e = Cb_e * Fl_b;

    F = Fr_e + Fl_e + Cb_e *[0 0 m*g]';
    %disp('Fr_e');
    %disp(Fr_e);
    %disp('Fl_e');
    %disp(Fl_e);

    r_cg_pr_e = Cb_e * [0 l 0]';
    r_cg_pl_e = Cb_e * [0 -l 0]';        
    %disp('r_cg_pr_e');
    %disp(r_cg_pr_e);
    %disp('r_cg_pl_e');
    %disp(r_cg_pl_e);
    Te_b = cross(r_cg_pr_e',Fr_e) + cross(r_cg_pl_e',Fl_e);

    ydd = F(2,1) / m;
    zdd = F(3,1) / m;
    phidd = Te_b(1,1) / Ixx;
    %disp('F');
    %disp(F);
    %disp('Te_b');
    %disp(Te_b);
    %disp(Te_b(1,2));
    

end
 
        
          

          
          
          
          
          
 
 