from DDPG_omnicopter2D import Agent
import gym
import numpy as np
from utils import plotLearning
import math
import matplotlib.pyplot as plt
##############
"""def calcDerivatives(x,act,xd,m = 1,Ixx = 0.2,l = 0.2):
    Tr = act[0]
    Tl = act[1]
    phi = x[4]
    
    phidd = (Tl-Tr)
    ydd = (Tr+Tl)*np.sin(phi)
    zdd = (Tr+Tl)*np.cos(phi)-10

    xd[0] = 0#x[1]
    xd[1] = 0#ydd
    xd[2] = 0#x[3]
    xd[3] = 0#zdd
    xd[4] = x[5]
    xd[5] = phidd
    return xd"""
    
def calcDerivatives(x,act,xd,m = 1,Ixx = 0.2,l = 0.2):
    # Extract the actions
    Tr = act[0]
    #print(Tr)
    phird = 0#act[1]
    Tl = act[1]
    phild = 0#act[3]
    # Calculate the rotor forces in earth axes
    # Create the tilting rotor direction cosines
    phir = 0#x[6]
    phil = 0#-x[7]
    Cpr_b = np.array([[1,0,0],
                      [0,math.cos(phir),-math.sin(phir)],
                      [0,math.sin(phir),math.cos(phir)]])
    Cpl_b = np.array([[1,0,0],
                      [0,math.cos(phil),-math.sin(phil)],
                      [0,math.sin(phil),math.cos(phil)]])
    Tvr = np.array([[0.0],[0.0],[-Tr]],dtype=object)
    Tvl = np.array([[0.0],[0.0],[-Tl]],dtype=object)
    Fr_b = Cpr_b @ Tvr
    Fl_b = Cpl_b @ Tvl
    # Now the body to NED axes
    phi = x[4]
    Cb_e = np.array([[1,0,0],
                      [0,math.cos(phi),-math.sin(phi)],
                      [0,math.sin(phi),math.cos(phi)]])
    # Then,
    Fr_e = Cb_e @ Fr_b
    Fl_e = Cb_e @ Fl_b
    # Total forces acting on the body are then,
    g = 0
    F = Fr_e + Fl_e + Cb_e @ np.array([[0],[0],[m * g]],dtype=object)
    # Now the moments. First transgform the moment arms into NED axes
    r_cg_pr_e = Cb_e @ np.array([[0],[l],[0]],dtype=object)
    r_cg_pl_e = Cb_e @ np.array([[0],[-l],[0]],dtype=object)
    # Now calculate the torque vector
    Tq = np.cross(np.transpose(r_cg_pr_e),np.transpose(Fr_e)) \
       + np.cross(np.transpose(r_cg_pl_e),np.transpose(Fl_e)) 
    #
    
    # With the forces and moments found, we can compute the linear and 
    # angular accelerations.
    ydd = -F[1][0] / m
    zdd = -F[2][0] / m
    phidd = Tq[0][0] / Ixx
    # Return the derivative vectors
    xd[0] = x[1]
    xd[1] = ydd
    xd[2] = x[3]
    xd[3] = zdd
    xd[4] = x[5]
    xd[5] = phidd
    #xd[6] = phird
    #xd[7] = phild
    return xd

def cal_polt(x, act, length_half = 0.5):
    
    Tl = act[0]
    Tr = act[1]
    
    y = x[0]
    z = x[2]

    phi = x[4]
    phil = 0#x[6]
    phir = 0#x[7]

    body_l_y = y - length_half*np.cos(phi)
    body_l_z = z - length_half*np.sin(phi)

    body_r_y = y + length_half*np.cos(phi)
    body_r_z = z + length_half*np.sin(phi)

    T_l_position_y = body_l_y - 0.5*(Tl+0.5) * np.cos(np.pi/2-phi-phil)
    T_l_position_z = body_l_z + 0.5*(Tl+0.5) * np.sin(np.pi/2-phi-phil)

    T_r_position_y = body_r_y + 0.5*(Tr+0.5) * np.cos(np.pi/2+phi-phir)
    T_r_position_z = body_r_z + 0.5*(Tr+0.5) * np.sin(np.pi/2+phi-phir)

    x_points = [[body_l_y, body_r_y],
         [body_l_y, T_l_position_y],
         [body_r_y, T_r_position_y]]
    y_points = [[body_l_z, body_r_z],
         [body_l_z, T_l_position_z],
         [body_r_z, T_r_position_z]]

    return x_points, y_points




##############
#env = gym.make('LunarLanderContinuous-v2')
dt = 0.01
agent = Agent(alpha=0.001, beta=0.001, input_dims=[6], tau=0.001, #env=env,
              batch_size=128, layer1_size=100, layer2_size=100, layer3_size=100, n_actions=2,
              chkpt_dir_actor='tmp_actor_onlyrotor',chkpt_dir_critic='tmp_critic_onlyrotor',
              chkpt_dir_actor_target='tar_actor_onlyrotor',chkpt_dir_critic_target='tar_critic_onlyrotor')
agent.load_models()
np.random.seed(0)

score_history = []
phi_error_save = []
for i in range(5):
    done = False
    score = 0
    #obs = env.reset()
    y = 0#np.random.rand()*10 - 5
    z = 0#np.random.rand()*10 - 5
    phi = 1*np.pi/(i+1)#np.random.rand()*np.pi - np.pi/2
    obs = np.array([y,0,z,0,phi,0],dtype = 'f')
    xd = np.array([0,0,0,0,0,0],dtype = 'f')
    step_num = 0

    min_reward = 0
    max_reward = -100000

    phi_error = []
    while not done:
        #print('observation',obs)
        act = agent.choose_action(obs)
        #act = [5,0]
        #print('action',act)
        #new_state, reward, done, info = env.step(act)
        xd = calcDerivatives(obs,act,xd)
        new_state = obs + xd*dt
        phi_error.append(new_state[4])
        """r1 = 10*((new_state[0]*new_state[0] + \
                  new_state[2]*new_state[2]+new_state[4]*new_state[4])<0.5)
        r2 = -100*(np.abs(new_state[0])>=15 or np.abs(new_state[2])>=15)
        r3 = -( 0.2*(act[0]+act[2])*(act[0]+act[2]) + \
                0.3*(act[0]-act[2])*(act[0]-act[2]) + \
                0.2*(act[1]+act[3])*(act[1]+act[3]) + \
                0.3*(act[1]-act[3])*(act[1]-act[3]) + \
                0.03*new_state[0]*new_state[0] + \
                0.03*new_state[2]*new_state[2] + \
                0.02*new_state[4]*new_state[4])"""
        """r1 = 10*((new_state[0]*new_state[0] + \
                  new_state[2]*new_state[2]+new_state[4]*new_state[4])<0.5)
        r2 = -100*(np.abs(new_state[0])>=10 or np.abs(new_state[2])>=10)
        r3 = -( 0.2*(act[0]+act[2])*(act[0]+act[2]) + \
                0.3*(act[0]-act[2])*(act[0]-act[2]) + \
                0.2*(act[1])*(act[1]) + \
                0.03*new_state[0]*new_state[0] + \
                0.03*new_state[2]*new_state[2])"""
        """r1 = 10*((new_state[0]*new_state[0] + new_state[2]*new_state[2])< 1)
        r2 = -10 * (np.abs(new_state[4])) #+ np.abs(new_state[6]) + np.abs(new_state[7]))
        r3 = -10*((new_state[0]*new_state[0] + new_state[2]*new_state[2])> 1)"""
        """r1 = 10*((new_state[0]*new_state[0] + \
                  new_state[2]*new_state[2]+new_state[4]*new_state[4])<0.5)
        r2 = -100*(np.abs(new_state[0])>=10 or np.abs(new_state[2])>=10)
        r3 = -( 0.2*(act[0]+act[1])*(act[0]+act[1]) + \
                0.3*(act[0]-act[1])*(act[0]-act[1]) + \
                0.03*new_state[0]*new_state[0] + \
                0.03*new_state[2]*new_state[2])"""
        r1 = 10*(np.abs(new_state[4])< 0.1)
        r2 = -50*(np.abs(new_state[4])> 0.1)
        r3 = 10*((new_state[0]*new_state[0] + \
                  new_state[2]*new_state[2])<0.5)
        r4 = -100*(np.abs(new_state[0])>=15 or np.abs(new_state[2])>=15)
        reward = r1 + r2 + r3 + r4

        if reward > max_reward:
            max_reward = reward
        if reward < min_reward:
            min_reward = reward
        
        if np.abs(obs[0])>=20 or np.abs(obs[2]) >= 20:
            done = True
        #print(new_state)
        agent.remember(obs, act, reward, new_state, int(done))
        agent.learn()
        score += reward
        obs = new_state
        
        if score > 600 or step_num >= 800:
            done = True
        #print('episode ', i, 'step ', step_num, 'reward %.2f' % reward,
            #'totaly reward %.2f' % score)
        step_num += 1
        #############
        """if 1>0:#i % 100 == 0:
            x_points,y_points = cal_polt(new_state, act, length_half = 0.5)
            #print(x_points[1])
            plt.xlim(-10,10)
            plt.ylim(-10,10)
            #plt.title(act)
            for t in range(3):
                plt.plot(x_points[t], y_points[t])
            plt.draw()
            plt.pause(0.005)
            plt.cla()"""

    score_history.append(score)
    print('episode ', i, 'score %.2f' % score,
           '100 game average %.2f' % np.mean(score_history[-100:]),
          'step numbers for each epi', step_num )
    print(obs)

    if i % 25 == 0:
        agent.save_models()
for ii in range(5):
    plt.plot(phi_error_save[ii])
    plt.xlabel('t')
    plt.ylabel('phi')
    plt.show()
#filename = 'omnicopter-stable_new9.png'
#plotLearning(score_history, filename, window=100)
