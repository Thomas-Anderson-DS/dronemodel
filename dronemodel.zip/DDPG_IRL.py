import pylab
import numpy as np

from maxent import *

from DDPG_omnicopter2D import Agent
import gym
from utils import plotLearning
import math
import matplotlib.pyplot as plt
yy_save = []
zz_save = []
phiphi_save = []
#####IRL functions
def idx_demo(env_low,
             env_high,
             one_feature):
    
    #env_low = np.array([-10, -20, -10, -20, 0, 0], dtype = 'float32')
    #env_high = np.array([10, 20, 10, 20, np.pi, 4*np.pi], dtype = 'float32')
    #[y yd z zd phi phid]
    #one_feature = 200
    #theta = 1200 The overall state is discretized into 1200 kinds.
    env_distance = (env_high - env_low) / one_feature  
    
    raw_demo = np.load(file="expert_trajectories_2.npy")
    print(np.shape(raw_demo[0][0]))
    
    for ii in range(20):
        y_save_step = []
        z_save_step = []
        phi_save_step = []
        for jj in range(200):
            y_save_step.append(raw_demo[ii][jj][0])
            z_save_step.append(raw_demo[ii][jj][2])
            phi_save_step.append(raw_demo[ii][jj][4])
        yy_save.append(y_save_step)
        zz_save.append(z_save_step)
        phiphi_save.append(phi_save_step)
        
    for ii in range(20):
        plt.plot(yy_save[ii], zz_save[ii])
    plt.title('expert system output demonstrations')
    plt.xlabel('y')
    plt.ylabel('z')
    plt.show()
    demonstrations = np.zeros((len(raw_demo), len(raw_demo[0]), 5))

    for x in range(len(raw_demo)):
        for y in range(len(raw_demo[0])):
            position_y_idx = int((raw_demo[x][y][0] - env_low[0]) / env_distance[0])
            position_yd_idx = int((raw_demo[x][y][1] - env_low[1]) / env_distance[1])
            position_z_idx = int((raw_demo[x][y][2] - env_low[2]) / env_distance[2])
            position_zd_idx = int((raw_demo[x][y][3] - env_low[3]) / env_distance[3])
            position_phi_idx = int((raw_demo[x][y][4] - env_low[4]) / env_distance[4])
            position_phid_idx = int((raw_demo[x][y][5] - env_low[5]) / env_distance[5])
        
            state_idx = position_y_idx + position_yd_idx + \
                        position_z_idx + position_zd_idx + \
                        position_phi_idx + position_phid_idx
            if state_idx >= 1200:
                state_idx = 1199
            demonstrations[x][y][0] = state_idx
            demonstrations[x][y][1] = raw_demo[x][y][6] # Tl
            demonstrations[x][y][2] = raw_demo[x][y][7] # phild
            demonstrations[x][y][3] = raw_demo[x][y][8] # Tr
            demonstrations[x][y][4] = raw_demo[x][y][9] # phird
    print(np.shape(demonstrations))
    return demonstrations

def idx_state(env_low,
              env_high,
              state, one_feature):
    
    env_distance = (env_high - env_low) / one_feature
    #print(state[0])
    #print(env_low[0])
    position_y_idx = int((state[0] - env_low[0]) / env_distance[0])
    position_yd_idx = int((state[1] - env_low[1]) / env_distance[1])
    position_z_idx = int((state[2] - env_low[2]) / env_distance[2])
    position_zd_idx = int((state[3] - env_low[3]) / env_distance[3])
    position_phi_idx = int((state[4] - env_low[4]) / env_distance[4])
    position_phid_idx = int((state[5] - env_low[5]) / env_distance[5])
    
    state_idx = position_y_idx + position_yd_idx + \
                position_z_idx + position_zd_idx + \
                position_phi_idx + position_phid_idx
    return state_idx
#####IRL functions

#####env functions
"""def calcDerivatives(x,act,xd,m = 1,Ixx = 0.2,l = 0.2):
    Tr = act[0]
    Tl = act[1]
    phi = x[4]
    
    phidd = (Tl-Tr)
    ydd = (Tr+Tl)*np.sin(phi)
    zdd = (Tr+Tl)*np.cos(phi)-10

    xd[0] = 0#x[1]
    xd[1] = 0#ydd
    xd[2] = 0#x[3]
    xd[3] = 0#zdd
    xd[4] = x[5]
    xd[5] = phidd
    return xd"""
    
def calcDerivatives(x,act,xd,m = 1,Ixx = 0.2,l = 0.2):
    # Extract the actions
    Tr = act[2]
    #print(Tr)
    phird = act[3]
    Tl = act[0]
    phild = act[1]
    # Calculate the rotor forces in earth axes
    # Create the tilting rotor direction cosines
    phir = x[6]
    phil = -x[7]
    Cpr_b = np.array([[1,0,0],
                      [0,math.cos(phir),-math.sin(phir)],
                      [0,math.sin(phir),math.cos(phir)]])
    Cpl_b = np.array([[1,0,0],
                      [0,math.cos(phil),-math.sin(phil)],
                      [0,math.sin(phil),math.cos(phil)]])
    Tvr = np.array([[0.0],[0.0],[-Tr]],dtype=object)
    Tvl = np.array([[0.0],[0.0],[-Tl]],dtype=object)
    Fr_b = Cpr_b @ Tvr
    Fl_b = Cpl_b @ Tvl
    # Now the body to NED axes
    phi = x[4]
    Cb_e = np.array([[1,0,0],
                      [0,math.cos(phi),-math.sin(phi)],
                      [0,math.sin(phi),math.cos(phi)]])
    # Then,
    Fr_e = Cb_e @ Fr_b
    Fl_e = Cb_e @ Fl_b
    # Total forces acting on the body are then,
    g = 10
    F = Fr_e + Fl_e + Cb_e @ np.array([[0],[0],[m * g]],dtype=object)
    # Now the moments. First transgform the moment arms into NED axes
    r_cg_pr_e = Cb_e @ np.array([[0],[l],[0]],dtype=object)
    r_cg_pl_e = Cb_e @ np.array([[0],[-l],[0]],dtype=object)
    # Now calculate the torque vector
    Tq = np.cross(np.transpose(r_cg_pr_e),np.transpose(Fr_e)) \
       + np.cross(np.transpose(r_cg_pl_e),np.transpose(Fl_e)) 
    #
    
    # With the forces and moments found, we can compute the linear and 
    # angular accelerations.
    ydd = -F[1][0] / m
    zdd = -F[2][0] / m
    phidd = Tq[0][0] / Ixx
    # Return the derivative vectors
    xd[0] = x[1]
    xd[1] = ydd
    xd[2] = x[3]
    xd[3] = zdd
    xd[4] = x[5]
    xd[5] = phidd
    xd[6] = phird
    xd[7] = phild
    return xd

def cal_polt(x, act, length_half = 0.5):
    
    Tl = act[2]
    Tr = act[0]
    
    y = x[0]
    z = x[2]

    phi = x[4]
    phil = x[6]
    phir = x[7]

    body_l_y = y - length_half*np.cos(phi)
    body_l_z = z - length_half*np.sin(phi)

    body_r_y = y + length_half*np.cos(phi)
    body_r_z = z + length_half*np.sin(phi)

    T_l_position_y = body_l_y - 0.5*(Tl+0.5) * np.cos(np.pi/2-phi-phil)
    T_l_position_z = body_l_z + 0.5*(Tl+0.5) * np.sin(np.pi/2-phi-phil)

    T_r_position_y = body_r_y + 0.5*(Tr+0.5) * np.cos(np.pi/2+phi-phir)
    T_r_position_z = body_r_z + 0.5*(Tr+0.5) * np.sin(np.pi/2+phi-phir)

    x_points = [[body_l_y, body_r_y],
         [body_l_y, T_l_position_y],
         [body_r_y, T_r_position_y]]
    y_points = [[body_l_z, body_r_z],
         [body_l_z, T_l_position_z],
         [body_r_z, T_r_position_z]]

    return x_points, y_points
#####ENV functions


def main():
    #IRL parameters
    n_states = 1200 # every state parameters - 200
    one_feature = 200 # number of state per one feature
    feature_matrix = np.eye((n_states)) # (1200, 1200)

    gamma = 0.99
    ddpg_learning_rate = 0.03
    theta_learning_rate = 0.05

    env_low = np.array([-10, -20, -10, -20, 0, 0], dtype = 'float32')
    env_high = np.array([10, 20, 10, 20, np.pi, 4*np.pi], dtype = 'float32')

    demonstrations = idx_demo(env_low, env_high, one_feature)

    expert = expert_feature_expectations(feature_matrix, demonstrations)

    learner_feature_expectations = np.zeros(n_states)


    #DDPG agent
    dt = 0.01
    agent = Agent(alpha=0.001, beta=0.001, input_dims=[8], tau=0.001, #env=env,
              batch_size=128, layer1_size=100, layer2_size=100, layer3_size=100, n_actions=4,
              chkpt_dir_actor='tmp_actor_flycontrol_irl2',chkpt_dir_critic='tmp_critic_flycontrol_irl2',
              chkpt_dir_actor_target='tar_actor_flycontrol_irl2',chkpt_dir_critic_target='tar_critic_flycontrol_irl2')

    #theta = -(np.random.uniform(size=(n_states,)))
    #print(np.shape(theta))
    agent.load_models()
    theta = np.load("IRL_REWARD_NN_2000.npy")
    #print(np.shape(theta))

    np.random.seed(0)

    score_history = []

    y_save = []
    z_save = []
    phi_save = []
    irl_reward_save = []
    
    #train process
    for episode in range(20):
        done = False
        score_reward = 0
        score_Irl_reward = 0

        y = 0
        z = 0
        phi = 0
        #env.reset()
        y = 0#np.random.rand()*10 - 5
        z = 0#np.random.rand()*10 - 5
        phi = 0#np.random.rand()*np.pi - np.pi/2
        obs = np.array([y,0,z,0,phi,0,0,0],dtype = 'f')
        xd = np.array([0,0,0,0,0,0,0,0],dtype = 'f')

        #step count
        step_num = 0

        min_reward = 0
        max_reward = -100000

        #update reward function for every 50 episodes
        if (episode != 0 and episode == 100) or (episode > 100 and episode % 50 == 0):
            learner = learner_feature_expectations / episode
            #print(expert)
            #print(learner)
            theta = maxent_irl(expert, learner, theta, theta_learning_rate)

        y_save_step = []
        z_save_step = []
        phi_save_step = []

        action_save = []
        
        while not done:

            state_idx = idx_state(env_low, env_high, obs[0:6], one_feature)
            
            act = agent.choose_action(obs)
            #act[0] = act[0] + 5
            #act[2] = act[2] + 5
            
            xd = calcDerivatives(obs,act,xd)
            new_state = obs + xd*dt

            action_save.append(act[0])

            r1 = 10*((new_state[0]*new_state[0] + \
                      new_state[2]*new_state[2]+new_state[4]*new_state[4])<0.5)
            r2 = -100*(np.abs(new_state[0])>=15 or np.abs(new_state[2])>=15)
            r3 = -( 0.2*(act[0]+act[2])*(act[0]+act[2]) + \
                    0.3*(act[0]-act[2])*(act[0]-act[2]) + \
                    0.2*(act[1]+act[3])*(act[1]+act[3]) + \
                    0.3*(act[1]-act[3])*(act[1]-act[3]) + \
                    0.03*new_state[0]*new_state[0] + \
                    0.03*new_state[2]*new_state[2] + \
                    0.02*new_state[4]*new_state[4])
            reward = r1 + r2 + r3

            irl_reward = get_reward(feature_matrix, theta, n_states, state_idx)
            next_state_idx = idx_state(env_low, env_high, new_state[0:6], one_feature)
            learner_feature_expectations += feature_matrix[int(next_state_idx)]

            """y_save_step.append(new_state[0])
            z_save_step.append(new_state[2]/2.25)
            phi_save_step.append(new_state[4]*4)"""

            agent.remember(obs, act, irl_reward, new_state, int(done))
            agent.learn()
            score_reward += reward
            score_Irl_reward += irl_reward
            obs = new_state

            
            
            if score_reward > 600 or step_num >= 210:
                done = True
            
            step_num += 1
            #############
            if 1>0:#episode % 100 == 0:
                x_points,y_points = cal_polt(new_state, act, length_half = 0.5)
                plt.xlim(-10,10)
                plt.ylim(-10,10)
                for t in range(3):
                    plt.plot(x_points[t], y_points[t])
                plt.draw()
                plt.pause(0.005)
                plt.cla()
        #plt.plot(action_save)
        #plt.show()
        if score_Irl_reward > -30:
            y_save.append(y_save_step)
            z_save.append(z_save_step)
            phi_save.append(phi_save_step)
            irl_reward_save.append(score_Irl_reward)
        if np.shape(y_save)[0] == 20:
            break
        
        score_history.append(score_Irl_reward)
        print('episode ', episode, 'score_reward %.2f' % score_reward,
              'episode ', episode, 'score_Irl_reward %.2f' % score_Irl_reward,
               '100 game average %.2f' % np.mean(score_history[-100:]),
              'step numbers for each epi', step_num )
        
        """if episode % 100 == 0:
            agent.save_models()
            np.save("IRL_REWARD_NN_2000_repair2.npy",theta)"""

    plt.xlabel('y')
    plt.ylabel('z')
    for ii in range(20):
        plt.plot(y_save[ii], z_save[ii])
    plt.legend(labels=['reward='+str(irl_reward_save[0]),
                       'reward='+str(irl_reward_save[1]),
                       'reward='+str(irl_reward_save[2]),
                       'reward='+str(irl_reward_save[3]),
                       'reward='+str(irl_reward_save[4])])
    plt.show()
    y_count = [0]*200
    z_count = [0]*200
    phi_count = [0]*200
    yy_count = [0]*200
    zz_count = [0]*200
    phiphi_count = [0]*200
    error_y = []
    error_z = []
    error_phi = []
    print(np.shape(y_save))
    print(np.shape(yy_save))
    for ii in range(20):
        for jj in range(200):
            #print(jj)
            y_count[jj] += y_save[ii][jj]/20
            z_count[jj] += z_save[ii][jj]/20
            phi_count[jj] += phi_save[ii][jj]/20

            yy_count[jj] += yy_save[ii][jj]/20
            zz_count[jj] += zz_save[ii][jj]/20
            phiphi_count[jj] += phiphi_save[ii][jj]/20
    for jj in range(200):
        error_y.append(y_count[jj]-yy_count[jj])
        error_z.append(z_count[jj]-zz_count[jj])
        error_phi.append(phi_count[jj]-phiphi_count[jj])
    
    
    
    plt.title('average y error for 20 episodes')
    plt.plot(error_y)
    plt.xlabel('t')
    plt.ylabel('error')
    plt.show()

    plt.title('average z error for 20 episodes')
    plt.plot(error_z)
    plt.xlabel('t')
    plt.ylabel('error')
    plt.show()

    plt.title('average phi error for 20 episodes')
    plt.plot(error_phi)
    plt.xlabel('t')
    plt.ylabel('error')
    plt.show()
    
        

    filename = 'omnicopter-IRL2000_repair2.png'
    plotLearning(score_history, filename, window=100)


main()




















    




















