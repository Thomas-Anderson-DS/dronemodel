import gym
import readchar
import numpy as np
import sys

import pylab
from maxent import *
from DDPG_omnicopter2D import Agent
import gym
from utils import plotLearning
import math
import matplotlib.pyplot as plt
import msvcrt


#import tty
#import termios

#######ENV
def calcDerivatives(x,act,xd,m = 1,Ixx = 0.2,l = 0.2):
    # Extract the actions
    Tr = act[2]
    #print(Tr)
    phird = act[3]
    Tl = act[0]
    phild = act[1]
    # Calculate the rotor forces in earth axes
    # Create the tilting rotor direction cosines
    phir = x[6]
    phil = -x[7]
    Cpr_b = np.array([[1,0,0],
                      [0,math.cos(phir),-math.sin(phir)],
                      [0,math.sin(phir),math.cos(phir)]])
    Cpl_b = np.array([[1,0,0],
                      [0,math.cos(phil),-math.sin(phil)],
                      [0,math.sin(phil),math.cos(phil)]])
    Tvr = np.array([[0.0],[0.0],[-Tr]],dtype=object)
    Tvl = np.array([[0.0],[0.0],[-Tl]],dtype=object)
    Fr_b = Cpr_b @ Tvr
    Fl_b = Cpl_b @ Tvl
    # Now the body to NED axes
    phi = x[4]
    Cb_e = np.array([[1,0,0],
                      [0,math.cos(phi),-math.sin(phi)],
                      [0,math.sin(phi),math.cos(phi)]])
    # Then,
    Fr_e = Cb_e @ Fr_b
    Fl_e = Cb_e @ Fl_b
    # Total forces acting on the body are then,
    g = 10
    F = Fr_e + Fl_e + Cb_e @ np.array([[0],[0],[m * g]],dtype=object)
    # Now the moments. First transgform the moment arms into NED axes
    r_cg_pr_e = Cb_e @ np.array([[0],[l],[0]],dtype=object)
    r_cg_pl_e = Cb_e @ np.array([[0],[-l],[0]],dtype=object)
    # Now calculate the torque vector
    Tq = np.cross(np.transpose(r_cg_pr_e),np.transpose(Fr_e)) \
       + np.cross(np.transpose(r_cg_pl_e),np.transpose(Fl_e)) 
    #
    
    # With the forces and moments found, we can compute the linear and 
    # angular accelerations.
    ydd = -F[1][0] / m
    zdd = -F[2][0] / m
    phidd = -Tq[0][0] / Ixx
    
    # Return the derivative vectors
    xd[0] = x[1]
    xd[1] = ydd
    xd[2] = x[3]
    xd[3] = zdd
    xd[4] = x[5]
    xd[5] = phidd
    xd[6] = phird
    xd[7] = phild
    return xd

def cal_polt(x, act, length_half = 0.5):
    
    Tl = act[0]
    Tr = act[2]
    
    y = x[0]
    z = x[2]*2.5

    phi = x[4]/4
    phil = x[7]
    phir = x[6]

    body_l_y = y - length_half*np.cos(phi)
    body_l_z = z - length_half*np.sin(phi)

    body_r_y = y + length_half*np.cos(phi)
    body_r_z = z + length_half*np.sin(phi)

    T_l_position_y = body_l_y - 0.5*(Tl+0.5) * np.cos(np.pi/2-phi-phil)
    T_l_position_z = body_l_z + 0.5*(Tl+0.5) * np.sin(np.pi/2-phi-phil)

    T_r_position_y = body_r_y + 0.5*(Tr+0.5) * np.cos(np.pi/2+phi-phir)
    T_r_position_z = body_r_z + 0.5*(Tr+0.5) * np.sin(np.pi/2+phi-phir)

    x_points = [[body_l_y, body_r_y],
         [body_l_y, T_l_position_y],
         [body_r_y, T_r_position_y]]
    y_points = [[body_l_z, body_r_z],
         [body_l_z, T_l_position_z],
         [body_r_z, T_r_position_z]]

    return x_points, y_points
#######
"""def readchar():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch

def readkey(getchar_fn=None):
    getchar = getchar_fn or readchar
    c1 = getchar()
    if ord(c1) != 0x1b:
        return c1
    c2 = getchar()
    if ord(c2) != 0x5b:
        return c1
    c3 = getchar()
    return chr(0x10 + ord(c3) - 65)"""


#env = gym.make('MountainCar-v0')

trajectories = []
episode_step = 0
dt = 0.01

y_save = []
z_save = []
for episode in range(20): # n_trajectories : 20
    trajectory = []
    step = 0

    #env.reset()
    y = 0#np.random.rand()*10 - 5
    z = 0#np.random.rand()*10 - 5
    phi = 0#np.random.rand()*np.pi - np.pi/2
    phir = 0#np.random.rand()*np.pi - np.pi/2
    phil = 0#np.random.rand()*np.pi - np.pi/2
    obs = np.array([y,0,z,0,phi,0,phir,phil],dtype = 'f')
    xd = np.array([0,0,0,0,0,0,0,0],dtype = 'f')

    act = np.array([0,0,0,0],dtype = 'f')
    print(episode)
    y_save_step = []
    z_save_step = []

    new_error = 0
    error = 0
    error_sum = 0
    
    while True:
        
        if 1>0:#i % 100 == 0:
                x_points,y_points = cal_polt(obs, act, length_half = 0.5)
                plt.xlim(-10,10)
                plt.ylim(-10,10)
                for t in range(3):
                    plt.plot(x_points[t], y_points[t])
                plt.draw()
                plt.pause(0.005)
                plt.cla()
        
        #print("step", step)
        #print(act)
        """act[0] = 5*np.sin((1+episode/60)*1.5*step*0.01)
        act[1] = 5*np.cos((1+episode/60)*1.5*step*0.01)
        act[2] = 5*np.cos((1+episode/60)*1.5*step*0.01)
        act[3] = 5*np.cos((1+episode/60)*1.5*step*0.01)"""
        act[0] = 5*np.sin((1+episode/40)*1.5*step*0.01)
        act[1] = 5*np.cos((1+episode/40)*1.5*step*0.01)
        act[2] = 5*np.cos((1+episode/40)*1.5*step*0.01)
        act[3] = 5*np.sin((1+episode/40)*1.5*step*0.01)
        """if episode == 0:
            
            act[0] = 6*np.sin((1+episode/40)*1.5*step*0.01)+5
            act[1] = 6*np.cos((1+episode/40)*1.5*step*0.01)
            act[2] = 6*np.cos((1+episode/40)*1.5*step*0.01)+5
            act[3] = 6*np.sin((1+episode/40)*1.5*step*0.01)








        
                
        if episode == 1:
            
            act[0] = 4*np.sin((1+episode/40)*1.5*step*0.01)+4.5
            act[1] = 4*np.cos((1+episode/40)*1.5*step*0.01)
            act[2] = 4*np.cos((1+episode/40)*1.5*step*0.01)+4.5
            act[3] = 4*np.sin((1+episode/40)*1.5*step*0.01)
            if step > 80:
                act[0] = 0#3.5*np.sin((1+episode/40)*1.5*step*0.01)+2.5
                act[1] = 3.5*np.cos((1+episode/40)*1.5*step*0.01)
                act[2] = 3.5*np.cos((1+episode/40)*1.5*step*0.01)+2.5
                act[3] = 3.5*np.sin((1+episode/40)*1.5*step*0.01)
            if step > 130:
                act[0] = 0
                act[1] = 2*np.cos((1+episode/40)*1.5*step*0.01)
                act[2] = 0#2*np.cos((1+episode/40)*1.5*step*0.01)+2
                act[3] = 0"""
        
        xd = calcDerivatives(obs,act,xd)
        new_state = obs + xd*dt
        #print(obs)
        
        y_save_step.append(new_state[0])
        z_save_step.append(new_state[2])

        """if obs[4] > 0:
            new_error = obs[4] % (2*np.pi)
            act[0] = 15*(new_error-0.5*abs(obs[5]))
            act[1] = -obs[7]
            act[2] = -15*(new_error-0.5*abs(obs[5]))
            act[3] = -obs[6]
        if obs[4] < 0:
            new_error = obs[4] % (2*np.pi) - 2 * np.pi
            act[0] = 15*(new_error+0.5*abs(obs[5]))
            act[1] = -obs[7]
            act[2] = -15*(new_error+0.5*abs(obs[5]))
            act[3] = -obs[6]"""

        """theta = abs(np.arctan((0-new_state[2])/(0-new_state[0])))
        if new_state[0] > 0 and new_state[2] > 0:
            if new_state[7] > 0:
                operator = new_state[4] % (2*np.pi)
                if operator <= np.pi/2 - theta:
                    
            else:
                operator = obs[4] % (2*np.pi) - 2 * np.pi"""

        """act[0] = 5
        act[1] = -10
        act[2] = 5
        act[3] = 0"""

        error = new_error
        error_sum += abs(error)
        if  step > 150: # trajectory_length : 200
            break
        #if new_state[0]*new_state[0]+new_state[2]*new_state[2] < 0.1:
        #    break

        trajectory.append((new_state[0], new_state[1], new_state[2], new_state[3], new_state[4], new_state[5], act[0], act[1], act[2], act[3]))
        step += 1

                
        obs = new_state
        
    trajectory_numpy = np.array(trajectory)
    print("trajectory_numpy.shape", trajectory_numpy.shape)
    trajectories.append(trajectory)

    y_save.append(y_save_step)
    z_save.append(z_save_step)

for ii in range(20):
    plt.plot(y_save[ii], z_save[ii])
#plt.legend(labels=['Target trajectory',
 #                      'Inverse simulation result'])
plt.title('expert system output demonstrations')
plt.xlabel('y')
plt.ylabel('z')
plt.show()
plt.show()
yy = []
"""for ii in range(len(y_save[0])):
    yy.append(y_save[0][ii]-y_save[1][ii])
plt.plot(yy)
plt.legend(labels=['error on y'])
plt.show()"""
"""zz = []
for ii in range(len(z_save[0])):
    zz.append(z_save[0][ii]-z_save[1][ii])
plt.plot(zz)
plt.legend(labels=['error on z'])
plt.show()"""


np_trajectories = np.array(trajectories)
print("np_trajectories.shape", np_trajectories.shape)

#np.save("expert_trajectories_up", arr=np_trajectories)
