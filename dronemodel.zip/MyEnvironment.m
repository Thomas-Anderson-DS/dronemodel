classdef MyEnvironment < rl.env.MATLABEnvironment
    %MYENVIRONMENT: Template for defining custom environment in MATLAB.    
    
    %% Properties (set properties' attributes accordingly)
    properties
        % Specify and initialize environment's necessary properties    
        % Acceleration due to gravity in m/s^2
        m = 1;              % mass(kg)
        Ixx = 0.1;          % roll inertia (kgm^2)
        l = 0.2;            % moment arm
        g = 9.8;    
        dt = 0.01;
        reward_acc = 0;
        act_initial = [5 0 5 0];
    end
    
    properties
        % Initialize system state [x,dx,theta,dtheta]'
        State = zeros(8,1)
    end
    
    properties(Access = protected)
        % Initialize internal flag to indicate episode termination
        IsDone = false        
    end

    %% Necessary Methods
    methods              
        % Contructor method creates an instance of the environment
        % Change class name and constructor name accordingly
        function this = MyEnvironment()
            % Initialize Observation settings
            ObservationInfo = rlNumericSpec([8 1]);
            ObservationInfo.Name = 'omnicopter States';
            ObservationInfo.Description = 'y, yd, z, zd, phi, phid, phil, phir';
            
            % Initialize Action settings   
            ActionInfo = rlFiniteSetSpec(1:16);
            ActionInfo.Name = 'omnicopter Action';
            
            % The following line implements built-in functions of RL env
            this = this@rl.env.MATLABEnvironment(ObservationInfo,ActionInfo);
            
            % Initialize property values and pre-compute necessary values
            %updateActionInfo(this);
        end
        
        % Apply system dynamics and simulates the environment with the 
        % given action for one step.
        function [Observation,Reward,IsDone,xd] = step(this,x,act)         
            
            
            
            % Unpack state vector
            Tl = act(1);
            Tr = act(3);
            phird = act(2);
            phild = act(4);
            phil = x(7);
            phir = x(8);
            phi = x(4);

            Cpl_b = [1 0 0;...
                     0 cos(phil) -sin(phil);...
                     0 sin(phil) cos(phil)];

            Cpr_b = [1 0 0;...
                     0 cos(phir) -sin(phir);...
                     0 sin(phir) cos(phir)];

            Cb_e = [1 0 0;...
                    0 cos(phi) -sin(phi);...
                    0 sin(phi) cos(phi)];    

            Tvr = [0.0 0.0 -Tr];
            Tvl = [0.0 0.0 -Tl];         

            Fr_b = Cpr_b * Tvr';
            Fl_b = Cpl_b * Tvl';


            Fr_e = Cb_e * Fr_b;
            Fl_e = Cb_e * Fl_b;

            F = Fr_e + Fl_e + Cb_e *[0 0 this.m*this.g]';


            r_cg_pr_e = Cb_e * [0 this.l 0]';
            r_cg_pl_e = Cb_e * [0 -this.l 0]';        

            Te_b = cross(r_cg_pr_e',Fr_e) + cross(r_cg_pl_e',Fl_e);

            ydd = F(2,1) / this.m;
            zdd = F(3,1) / this.m;
            phidd = Te_b(1,1) / this.Ixx;

            xd(1) = x(1);
            xd(2) = ydd;
            xd(3) = x(3);
            xd(4) = zdd;
            xd(5) = x(5);
            xd(6) = phidd;
            xd(7) = phild;
            xd(8) = phird;
            
            Observation = x + xd*this.dt;
            
            % Update system states
            this.State = Observation;
            
            Lim = [-5 -5 0 10];
            plotOmnicopter(y,z,phi,Tl,phil,Tr,phir,Lim);
            
            % Check terminal condition
            %X = Observation(1);
            %Theta = Observation(3);
            %IsDone = abs(X) > this.DisplacementThreshold || abs(Theta) > this.AngleThreshold;
            %this.IsDone = IsDone;
            
            % Get reward
            %Reward = getReward(this);
            Reward = (1 - sqrt((Observation(1)-1)^2+(Observation(3)-1)^2) - abs(Observation(5)/pi)); 
            
            % (optional) use notifyEnvUpdated to signal that the 
            % environment has been updated (e.g. to update visualization)
            notifyEnvUpdated(this);
        end
        
        % Reset environment to initial state and output initial observation
        function InitialObservation = reset(this)
            
            
            y = 0;
            z = 0;
            yd = 0;
            zd = 0;
            phi = 0;
            phid = 0;
            phil = 0;
            phir = 0;
            
            InitialObservation = [y, yd, z, zd, phi, phid, phil, phir];
            this.State = InitialObservation;
            
            % (optional) use notifyEnvUpdated to signal that the 
            % environment has been updated (e.g. to update visualization)
            notifyEnvUpdated(this);
        end
    end
    
end
